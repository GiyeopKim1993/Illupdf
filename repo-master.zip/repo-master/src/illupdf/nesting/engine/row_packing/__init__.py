"""Row/beam based outline nesting engine."""
