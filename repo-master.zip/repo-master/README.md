# illupdf

`illupdf`는 투명 배경의 PNG/WebP 이미지를 굿즈 인쇄용 PDF로 변환하고, 여러 PDF를 한 장의 시트에 배치(nesting)하는 Python CLI 도구입니다.

- **Converting**: 투명 이미지 → 레이어 포함 PDF + 레이어별 분리 PDF 생성
- **Nesting**: 여러 PDF → 지정한 시트(기본 400×300mm) 안에 자동 배치한 PDF 생성

## 설치

Python 3.11 이상이 필요합니다.

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -e .
```

설치 후 CLI 명령은 다음 엔트리포인트로 제공됩니다.

```bash
illupdf --help
```

## 사용법

### 1. 이미지 변환

```bash
# keyring(65mm) 또는 stand(148mm) 프리셋으로 변환
illupdf convert art.png --preset keyring
illupdf convert art.png --preset stand

# 크기 직접 지정 (최종 외곽 긴 변 기준, mm)
illupdf convert art.png --preset keyring --size 50

# 여러 이미지 / 디렉터리 일괄 변환 (CPU 코어 기반 병렬, --workers로 지정 가능)
illupdf convert img1.png img2.webp --preset stand
illupdf convert ./input_images --preset keyring --output ./output_pdfs
```

변환 시 입력 파일당 다음 4개 PDF가 생성됩니다.

| 출력 | 설명 |
| --- | --- |
| `<name>_<preset>.pdf` | Raster, White, Outline 레이어(OCG)를 묶은 combined PDF |
| `<name>_<preset>_raster.pdf` | 원본 래스터 이미지 레이어만 포함한 PDF |
| `<name>_<preset>_white.pdf` | 흰색 인쇄 영역(spot color) 레이어만 포함한 PDF |
| `<name>_<preset>_outline.pdf` | 커팅/외곽선 레이어만 포함한 PDF |

| 옵션 | 기본값 | 설명 |
| --- | ---: | --- |
| `--preset` | (필수) | `keyring`(키링 구멍/보스 생성) 또는 `stand`(받침/연결 형상) |
| `--size` | 프리셋 기본값 | 최종 외곽 긴 변 기준 크기(mm) |
| `--output` | `<input>_<preset>.pdf` | 출력 경로 또는 디렉터리 |
| `--emit` | `text` | 진행 이벤트 출력 형식 (`text` / `ndjson`) |
| `--workers` | `0` (자동) | 병렬 변환 워커 프로세스 수. `0` = `min(CPU 코어, 입력 수)` (상한 32) |

### 2. PDF 네스팅

```bash
# 개별 파일 지정
illupdf nest out/a_keyring.pdf out/b_keyring.pdf --output nested/

# 디렉터리 지정 (재귀 탐색, counts.json/counts.csv로 PDF별 수량 지정 가능)
illupdf nest ./output_pdfs --output nested/
```

네스팅 프리셋은 **입력 아이템 크기로 자동 선정**됩니다 (시트는 400×300mm 고정).

- 아이템 long side가 **66mm 미만** → `keyring` (4행 고정 Y그리드)
- 아이템 long side가 **66mm 이상 149mm 미만** → `stand` (2행 중앙 정렬)
- **keyring + stand 혼합** → `mixed` (키링 여러 개를 수직 스택으로 묶어 스탠드형 배치)
  - 각 키링의 **긴 면/짧은 면 실제 치수**를 사용해, 스택 총 높이가 **148mm를 넘지 않는 최대 개수**로 그룹핑
  - 키링마다 **세움(긴 면 세로)/눕힘(짧은 면 세로) 방향을 자유 선택**해 최대 개수를 채우고, 개수가 유지되는 한 스택 폭이 최소가 되도록 정리

입력 디렉터리에 `counts.json`(또는 `counts.csv`) 파일을 두면 PDF별 수량을 지정할 수 있습니다. 두 파일이 함께 있으면 오류가 나므로 하나만 사용하세요.

```json
// counts.json (스키마: illupdf-counts-v1)
{"schema": "illupdf-counts-v1", "items": [{"filename": "a_keyring.pdf", "count": 3}]}
```

```csv
# counts.csv (첫 줄에 스키마 선언 필수)
# illupdf-counts-v1
filename,count
a_keyring.pdf,3
```

| 옵션 | 기본값 | 설명 |
| --- | ---: | --- |
| `--output` / `-o` | `nested_output` | 출력 디렉터리 |
| `--count` | `1` | counts 파일에 없는 PDF의 기본 수량 |
| `--no-recursive` | 꺼짐 | 입력 디렉터리를 재귀 탐색하지 않음 |
| `--emit` | `text` | 진행 이벤트 출력 형식 (`text` / `ndjson`) |
| `--beam-width` | `8` | 행 생성 시 유지할 빔 상태 수 |
| `--row-candidate-limit` | `60` | 한 행에 고려할 소스 인스턴스 상한 |
| `--pair-precompute` / `--no-pair-precompute` | 켜짐 | 행 후보용 pair-offset 사전 계산 |
| `--pair-precompute-workers` | `1` | pair-offset 사전 계산 워커 수 |
| `--search-mode` | `hybrid` | pair-offset 탐색 방식 (`hybrid` / `linear`) |

### 3. Visualizer

처리 상태를 실시간으로 보여주는 웹 대시보드를 실행합니다. 명령 앞에 `visualize-`를 붙이면 브라우저가 열리고, 실행한 처리의 진행 이벤트가 웹에서 스트리밍됩니다. (내부적으로 `--emit ndjson`이 자동 적용됩니다.)

```bash
# 변환 처리 시각화
illupdf visualize-converting convert art.png --preset keyring

# 네스팅 처리 시각화
illupdf visualize-nesting nest ./output_pdfs

# 이미 생성된 NDJSON 이벤트 스트림을 stdin으로 재생
illupdf visualize-converting --stdin < events.ndjson
```

## 개발 및 테스트

```bash
python -m pip install -e .
```

참고: 자동 테스트(`tests/`)는 master 브랜치에 포함되어 있지 않으며, 아카이브 브랜치(`arena/019fabc2-repo`)에서 `python -m pytest -q`로 실행할 수 있습니다.

## 프로젝트 구조

```text
src/illupdf/
├── cli.py                      # 최상위 CLI 라우터
├── core.py                     # 공개 API re-export
├── converting/
│   ├── app/                    # 변환 use case, 출력 경로, 이벤트
│   ├── cli/                    # convert 명령 파서/핸들러
│   ├── engine/                 # 이미지 처리, 벡터화, 키링/스탠드 형상, PDF 생성
│   └── visualizer/             # 변환 visualizer
├── nesting/
│   ├── cli/                    # nest 명령 파서/핸들러
│   ├── engine/                 # PDF 파싱, row-packing 배치, 렌더링
│   └── visualizer/             # 네스팅 visualizer
└── visualizer.py               # visualizer 진입점
```

## Legacy notes

레거시/실험 구현(GA 옵티마이저 계열 등)은 현재 master 브랜치에는 포함되어 있지 않으며, 아카이브 브랜치(`arena/019fabc2-repo`)의 `docs/legacy.md`에 기록되어 있습니다.
